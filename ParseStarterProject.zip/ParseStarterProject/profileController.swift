//
//  profileController.swift
//  ParseStarterProject-Swift
//
//  Created by Daniel Barton on 2/10/21.
//  Copyright © 2021 Parse. All rights reserved.
//

import UIKit
import Parse

class profileController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var ProfileImage: UIImageView!
    
    @IBOutlet weak var boyOrGirlOutlet: UISwitch!
    
    @IBOutlet weak var interestsmOFOutlet: UISwitch!
    
    @IBOutlet weak var errorLabelOutlet: UILabel!
    
    @IBAction func profilePictureSelector(_ sender: AnyObject) {
    
        let imageSelector = UIImagePickerController();
        
        imageSelector.delegate = self;
        
        imageSelector.sourceType = UIImagePickerController.SourceType.photoLibrary;
        
        imageSelector.allowsEditing = false;
        
        self.present(imageSelector, animated: true, completion: nil);
        
    }
    
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : AnyObject]) {
    
            if let selectedImage = info[UIImagePickerController.InfoKey.originalImage] as! UIImage? {
                
               ProfileImage.image = selectedImage;
                
            }
            
            self.dismiss(animated: true, completion: nil);
            
            
            
        }
    
    
    
    @IBAction func updateProfile(_ sender: AnyObject) {

        PFUser.current()?["areMale"] = boyOrGirlOutlet.isOn;
        
        PFUser.current()?["areAttractedToMale"] = interestsmOFOutlet.isOn;

        // let profile = PFObject(className: "Profile");
        
        // profile["userId"] = PFUser.current()?.objectId!;
        
        var profilePicture = ProfileImage.image!.jpegData(compressionQuality: 1);
        
      //  var fileOfImage = PFFile(name: "ProfileImage.png", data: (profilePicture)!);
        
       // profile["profileImage"] = fileOfImage;
        
        
        PFUser.current()?["profileImage"] = PFFile(name: "ProfileImage.jpeg", data: profilePicture!);
        
        PFUser.current()?.saveInBackground(block: { (saved, notSaved) in
            
            
            if notSaved != nil {
                
                var errorMessage = "Profile update failed, please try again? ";
                
                let notSaved = notSaved as NSError?;
                
                if let parseFail = notSaved?.userInfo["error"] as? String {
                   
                    errorMessage = parseFail;
                   
                    }
                
                    // print("photo not saved?");
                
                self.errorLabelOutlet.alpha = 1;
                
                self.errorLabelOutlet.text = errorMessage;
                
            } else {
                
                 print("photo saved?");
                
               // self.ProfileImage.image = UIImage(named: "ProfileImage.png");
            }
 
        })

        
        
    //    let dataForImage = ProfileImage.image!.pngData();
        
        
     //   print(boyOrGirlOutlet.isOn);
        
      //  print(interestsmOFOutlet.isOn);
        
 }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        
// downloading images from the web and create accounts for them
        
        // add a message at the end saying no more for now? //
        
/*
         let url = ["enter urls here", " "];
        
         var counter = 0;
         
         for urls in url {
        
            counter += 1;
        
          let urlFind = URL(string: urls)!;
        
        do {
        
            let data = try Data(contentsOf: urlFind);
        
        let imageSource = PFFile(name: "profilePicture.jpeg", data: data);
        
        let user = PFUser();
        
        user["profileImage"] = imageSource;
         
        user.username = String(counter);
        
        user.password = "password";
        
        user["areAttractedToMale"] = true &&  false;
        
        user["areMale"] = true || false;
        
        let acl = PFACL();
        
        acl.getPublicWriteAccess = true;
        
        user.acl = acl;
        
        user.signUpInBackground(block: { (signedUp, notSignedUp) in
        
        if signedUp {
        
        print("user was successfully signed up? ");
        
        }
    })
        } catch {
        
        print("could not retrieve data?");
        
        }
     
    }
        
*/

        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    

    

     

    
    override func viewDidAppear(_ animated: Bool) {
        
        if let nameDisplay = PFUser.current()?["username"] as? String {
            
            self.nameLabel.text = nameDisplay;
            
        }
        
        
        if let interestsForMale = PFUser.current()?["areAttractedToMale"] as? Bool {
            
            interestsmOFOutlet.setOn(interestsForMale, animated: false);
            
        }
        
        if let profilePhoto = PFUser.current()?["profileImage"] as? PFFile {
            
            profilePhoto.getDataInBackground(block: { (photo, error) in
                
                if let dataForImage = photo {
                    
                    if let downloadedImageConversion = UIImage(data: dataForImage) {
                        
                        self.ProfileImage.image = downloadedImageConversion;
                        
                    }
                }
            })
        }

    }
}
