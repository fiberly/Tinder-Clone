//
//  MatchesTableCell.swift
//  ParseStarterProject-Swift
//
//  Created by Daniel Barton on 2/18/21.
//  Copyright © 2021 Parse. All rights reserved.
//

import UIKit
import Parse

class MatchesTableCell: UITableViewCell {

    @IBAction func sendMessageButton(_ sender: Any) {
        
        print(usernameOutput.text!);
        
        print(messageTextFieldOutlet.text!);
        
        let messageFromServer = PFObject(className: "message");
        
        messageFromServer["sender"] = PFUser.current()?.objectId!;
        
        messageFromServer["recipient"] = usernameOutput.text;
        
        messageFromServer["content"] = messageTextFieldOutlet.text;
        
        messageFromServer.saveInBackground();
        
    }
    
    @IBOutlet weak var imageViewOutlet: UIImageView!
    
    @IBOutlet weak var messageTextFieldOutlet: UITextField!
    
    @IBOutlet weak var sendButtonOutlet: UIButton!
    

    @IBOutlet weak var receivedMessage: UILabel!
    
    @IBOutlet weak var usernameOutput: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    // imageViewOutlet = CGRect(x: 10, y: 10, width: 10, height: 10);
     
}
