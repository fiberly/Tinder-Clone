//
//  MatchesVC.swift
//  ParseStarterProject-Swift
//
//  Created by Daniel Barton on 2/23/21.
//  Copyright © 2021 Parse. All rights reserved.
//

import UIKit
import Parse

class MatchesVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    //var UserIdentification = [""];
    
    var profilePhoto = [UIImage]();
    
    var usernameOutputs = [String]();
    
    var messages = [String]();
    

    @IBOutlet weak var tableViewOutlet: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        
        tableViewOutlet.delegate = self;
        
        tableViewOutlet.dataSource = self;
        
        // refreshPuller();
        
      //  refreshLoader = UIRefreshControl();
        
      //  refreshLoader.attributedTitle = NSAttributedString(string: "pull to refresh?");
        
     //   refreshLoader.addTarget(self, action: #selector(MatchesTableViewController.refreshPuller), for: UIControl.Event.valueChanged);
        
     //   tableView.addSubview(refreshLoader);
        
        
      //  self.tableViewOutlet.estimatedRowHeight = 150;
        
     //   self.tableViewOutlet.rowHeight = UITableView.automaticDimension;
        
        
        let query = PFUser.query();
        
        // checks if current user was confirmed
        query?.whereKey("confirmed", contains: PFUser.current()?.objectId);
        
        // checks if current user confirmed other person(s)
        query?.whereKey("objectId", containedIn: PFUser.current()?["confirmed"] as! [String]);
        
        query?.findObjectsInBackground(block: { (found, notFound) in
            
            if let users = found {
                
                for founds in users {
                    
                    if let user = founds as? PFUser {
                        
                        let photoOfUser = user["profileImage"] as! PFFile;
                        
                        photoOfUser.getDataInBackground(block: { (dataGot, dataNot) in
                            
                            if let photoOfUsers = dataGot {
                                
                                //self.profilePhoto.append(UIImage(data: photoOfUsers)!);
                                
                               // self.UserIdentification.append(user.objectId!);
                                
                              //  self.tableView.reloadData();
                                
                                let queryForMessages = PFQuery(className: "message");
                                
                                queryForMessages.whereKey("recipient", equalTo: (PFUser.current()?.objectId!)!);
                                
                                queryForMessages.whereKey("sender", equalTo: user.objectId!);
                                
                                queryForMessages.findObjectsInBackground(block: {  (success, error) in
                                    
                                    var userMessage = "No user name involving this user sent you a message?";
                                    
                                    if let successes = success {
                                        
                                        for successess in successes {
                                            
                                          // if let userMessage = successes as? PFObject {
                                            
                                            
                                            
                                    if let messageContained = successess["content"] as? String {
                                                    
                                                    userMessage = messageContained;
                                                    
                                                }
                                         //   }
                                        }
                                    }
                                    
                                    self.messages.append(userMessage);
                                    
                                    self.profilePhoto.append(UIImage(data: photoOfUsers)!);
                                    
                                    self.usernameOutputs.append(user["username"] as! String);
                                    
                                    self.tableViewOutlet.reloadData();
                                })
                            }
                        })
                    }
                }
            }
        })
    }

    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return profilePhoto.count;
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "messageIdentifier", for: indexPath) as! MatchesTableCell;
        
         cell.imageViewOutlet.image = profilePhoto[indexPath.row];
        
        cell.receivedMessage.text = "No messages have been gotten?";
        
        cell.usernameOutput.text = usernameOutputs[indexPath.row];
        
        cell.receivedMessage.text = messages[indexPath.row];

        return cell;
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
