//
//  ViewController2.swift
//  ParseStarterProject-Swift
//
//  Created by Daniel Barton on 2/7/21.
//  Copyright © 2021 Parse. All rights reserved.
//

import UIKit
import Parse

class ViewController2: UIViewController {
    
    var UserID = "";
    
    @IBOutlet weak var endLabel: UILabel!
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBAction func logOutAction(_ sender: AnyObject) {
   
        PFUser.logOut();
        
        performSegue(withIdentifier: "LogOutIdentifier", sender: self);
        
    }
    
    
    @IBAction func profilePage(_ sender: Any) {
    
        self.performSegue(withIdentifier: "profileIdentifier", sender: nil);
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        
        
      //  let tempImage: UIImage? = UIImage(named: "Person Silhouette.png")!;
        
     // tempImage = UIImageView(frame: CGRect(x: self.view.bounds.width / 2 - 100, y: self.view.bounds.height / 2 - 50, width: 200, height: 200));
        
      //  var imageViews = UIImageView(image: tempImage);
        
        
       // self.imageView.image = tempImage;
        
      //  self.view.addSubview(imageViews);
        
     //   imageView: UIImageView = PFUser.current()?["profileImage"] as! PFFile
        
        let gesture = UIPanGestureRecognizer(target: self, action: #selector(self.draggedPhoto(gestureRecognizer:)));
        
        imageView.isUserInteractionEnabled = true;
        
        imageView.addGestureRecognizer(gesture);
        
        PFGeoPoint.geoPointForCurrentLocation { (geographicPoint, error) in
            
            print(geographicPoint);
            
            
            if let geographicPoint = geographicPoint {
                
                PFUser.current()?["location"] = geographicPoint;
                
                PFUser.current()?.saveInBackground();
            }
        }
        
        
        photoUpdation()
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
        photoUpdation();
    
        
    }
    
    func photoUpdation() {
        
        let query = PFUser.query();
        
        print(PFUser.current());
        
        query?.whereKey("areMale", equalTo: (PFUser.current()?["areAttractedToMale"])!);
        
        query?.whereKey("areAttractedToMale", equalTo: (PFUser.current()?["areMale"])!);
        
        var usersIgnored = [""];
        
        // searches for users not in the confirmed or denied arrays
        if let confirmedUsers = PFUser.current()?["confirmed"] {
            
            usersIgnored += confirmedUsers as! Array;
            
        } else if PFUser.current()?["confirmed"] != nil {
            
            self.imageView.isHidden = true;
            
            self.endLabel.isHidden = false;
            
        } else {
            
            self.imageView.isHidden = false;
            
            self.endLabel.isHidden = true;
            
        }
        
        if let deniedUsers = PFUser.current()?["denied"] {
            
            usersIgnored += deniedUsers as! Array;
            
        } else if PFUser.current()?["denied"] != nil {
            
            self.imageView.isHidden = true;
            
            self.endLabel.isHidden = false;
            
        } else {
            
            self.imageView.isHidden = false;
            
            self.endLabel.isHidden = true;
            
        }
        
        /*
        if (PFUser.current()?["confirmed"] != nil && PFUser.current()?["denied"] != nil) != nil {
            
            self.imageView.isHidden = false;
            
            endLabel.isHidden = true;
            
        } else {
            
            self.imageView.isHidden = true;
            
            endLabel.isHidden = false;
            
        }
        */
        
        query?.whereKey("objectId", notContainedIn: usersIgnored);
        
        //
        if let latitude = (PFUser.current()?["location"] as AnyObject).latitude {
            
            if let longitude = (PFUser.current()?["location"] as AnyObject).longitude {
                
                query?.whereKey("location", withinGeoBoxFromSouthwest: PFGeoPoint(latitude: latitude - 1, longitude: longitude - 1), toNortheast: PFGeoPoint(latitude: latitude + 1, longitude: longitude + 1));
            }
        }
        query?.limit = 1;
        
        query?.findObjectsInBackground(block: { (foundData, errors) in
            
            if let NewUser = foundData {
                
                for foundDatas in NewUser {
                    
                    if let NewUsers = foundDatas as? PFUser {
                        
                        self.UserID = NewUsers.objectId!;
                        
                        let photoFile = NewUsers["profileImage"] as! PFFile;
                        
                        photoFile.getDataInBackground(block: { (photoData, errors) in
                            
                            if errors != nil {
                                
                                print(errors);
                            
                            }
                            
                            if let photoFiles = photoData {
                                
                                self.imageView.image = UIImage(data: photoFiles);
                                
                            }
                        })
                    }
                }
            }
        })
    }
    
    @objc func draggedPhoto(gestureRecognizer: UIPanGestureRecognizer) {
        
        print("image was dragged");
        
        let translation = gestureRecognizer.translation(in: view);
        
        let imageView = gestureRecognizer.view!;
        
        imageView.center = CGPoint(x: self.view.bounds.width / 2 + translation.x, y: self.view.bounds.height / 2 + translation.y);
        
        let xStartingAtCenter = imageView.center.x - self.view.bounds.width / 2;
        
        var rotation = CGAffineTransform(rotationAngle: xStartingAtCenter / 200);
        
        let scale = min(abs(100 / xStartingAtCenter), 1);
        
        var rotateAndMorph = rotation.scaledBy(x: scale, y: scale);
        
        imageView.transform = rotateAndMorph;
        
        if gestureRecognizer.state == UIGestureRecognizer.State.ended {
            
            var confirmedOrDenied = "";
            
            if imageView.center.x < 100 {
                
                confirmedOrDenied = "denied";
                
                print("not moved");
                
                photoUpdation();
                
            } else if imageView.center.x > self.view.bounds.width - 100 {
                
                confirmedOrDenied = "confirmed";
                
                print("image moved");
                
            }
            
            if confirmedOrDenied != "" && UserID != "" {
                
                PFUser.current()?.addUniqueObjects(from: [UserID], forKey: confirmedOrDenied);
                
                PFUser.current()?.saveInBackground(block: { (saved, notSaved) in
                    
                    print(PFUser.current());
                    
                    self.photoUpdation();
                    
                })
                
            }
            
            rotation = CGAffineTransform(rotationAngle: 0);
            
            rotateAndMorph = rotation.scaledBy(x: 1, y: 1);
            
            imageView.center = CGPoint(x: view.bounds.width / 2, y: view.bounds.height / 2)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
