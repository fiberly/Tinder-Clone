/**
* Copyright (c) 2015-present, Parse, LLC.
* All rights reserved.
*
* This source code is licensed under the BSD-style license found in the
* LICENSE file in the root directory of this source tree. An additional grant
* of patent rights can be found in the PATENTS file in the same directory.
*/

import UIKit
import Parse
import Bolts

class ViewController: UIViewController {
    
    var signUpCheck = true;
    
    var activitySpinner = UIActivityIndicatorView();
    
    @IBOutlet weak var usernameTFOutlet: UITextField!
    
    @IBOutlet weak var passwordTFOutlet: UITextField!
   
    @IBOutlet weak var signUpButtonOutlet: UIButton!
    
    @IBOutlet weak var loginButtonOutlet: UIButton!
    
    @IBOutlet weak var loginAndOrSignUpLabel: UILabel!
    
    @IBOutlet weak var errorMessageLabel: UILabel!
    
    @IBAction func signUpAction(_ sender: UIButton) {
        
        self.errorMessageLabel.alpha = 0;
        
        if usernameTFOutlet.text == "" || passwordTFOutlet.text == "" {
            
            alertPopUp(title: "Username and or password error?", message: "Try entering the credentials again?");
            
        } else {
            
            activitySpinner = UIActivityIndicatorView(frame: CGRect(x: 50, y: 0, width: 50, height: 50));
            
            activitySpinner.center = self.view.center;
            
            activitySpinner.hidesWhenStopped = true;
            
            activitySpinner.style = UIActivityIndicatorView.Style.gray;
            
            view.addSubview(activitySpinner);
            
            self.activitySpinner.startAnimating();
            
            UIApplication.shared.beginIgnoringInteractionEvents();
            
            
            if signUpCheck {
              
                let newUser = PFUser();
              
                newUser.username = usernameTFOutlet.text;
              
                newUser.password = passwordTFOutlet.text;
              
                let acl = PFACL();
                
                acl.getPublicWriteAccess = true;
                
                acl.getPublicReadAccess = true;
                
                newUser.acl = acl;
                
                newUser.signUpInBackground { (worked, errors) in
                
                    self.activitySpinner.stopAnimating();
                  
                    UIApplication.shared.endIgnoringInteractionEvents();
                    
                    if errors != nil {
                      
                        var showErrorMessage = "Please try signing up again?";
                       
                        let errors = errors as! NSError;
                       
                    
                    //    self.alertPopUp(title: "error from the server side :/", message: showErrorMessage);
                        
                        self.errorMessageLabel.text = showErrorMessage;
                        
                        self.errorMessageLabel.alpha = 1;
                        
                    } else {
                     
                        print("user signed up successfully!");
                     
                        self.performSegue(withIdentifier: "LogInIdentifier", sender: self);
                        
                        self.errorMessageLabel.alpha = 0;
                        
                    }
                }
                
            } else {
                
                PFUser.logInWithUsername(inBackground: usernameTFOutlet.text!, password: passwordTFOutlet.text!, block: { (login, didNotWork) in
                   
                    self.activitySpinner.stopAnimating();
                   
                    UIApplication.shared.endIgnoringInteractionEvents();
                    
                    if didNotWork != nil {
                      
                        var showErrorMessage2 = "Please try logging in again?";
                       
                        let didNotWork = didNotWork as NSError?;
                       
                        if let didNotWorkToString = didNotWork?.userInfo["error"] as? String {
                         
                            showErrorMessage2 = didNotWorkToString
                        
                        }
                       
                      //  self.alertPopUp(title: "Trouble logging in?", message: showErrorMessage2);
                        
                        self.errorMessageLabel.text = showErrorMessage2;
                        
                        self.errorMessageLabel.alpha = 1;
                        
                    } else {
                        
                        print("You are now logged in?");
                        
                        
                       // self.performSegue(withIdentifier: "LogInIdentifier", sender: self);
                        
                        self.sendUserToProfilePage();
                        
                        self.errorMessageLabel.alpha = 0;
                    
                    }
                })
            }
        }
        
        print(signUpCheck);
        
    }
    
    @IBAction func logInAction(_ sender: UIButton) {
    
        if signUpCheck {
            
            signUpCheck = false;
            
            signUpButtonOutlet.setTitle("Log In", for: []);
            
            loginButtonOutlet.setTitle("Sign Up", for: []);
            
            loginAndOrSignUpLabel.text = "Do you not have an account? ";
            
            
            
        } else {
            
            signUpCheck = true;
        
            signUpButtonOutlet.setTitle("Sign Up", for: []);
            
            loginButtonOutlet.setTitle("Log In", for: []);
            
            loginAndOrSignUpLabel.text = "Do you already have an account?";
            
            
        }
    }
    
    
    func alertPopUp(title: String, message: String) {
        
        let loginAndOrSignUpAlert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert);
        
        loginAndOrSignUpAlert.addAction(UIAlertAction(title: "Okay", style: .default, handler: { (alertAction) in
            
            self.dismiss(animated: true, completion: nil);
            
        }));
        
        self.present(loginAndOrSignUpAlert, animated: true, completion: nil);
        
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        

        
        self.navigationController?.navigationBar.isHidden = true;
        
        sendUserToProfilePage();
        
    }
    
    func sendUserToProfilePage() {
        
        if PFUser.current() != nil {
            
            
            if PFUser.current()?["areMale"] != nil && PFUser.current()?["areAttractedToMale"] != nil && PFUser.current()?["profileImage"] != nil {
                
                
                performSegue(withIdentifier: "LogInIdentifier", sender: nil);
                
            } else {
                
                performSegue(withIdentifier: "loginToProfile", sender: nil);
                
            }
            
            
            print((PFUser.current()?.username)!);
            
            
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
     

        
        /* sending data to parse */
/*
        let testObject = PFObject(className: "TestObject2")
        
        testObject["foo"] = "bar"
        
        testObject.saveInBackground { (success, error) -> Void in
            
            // added test for success 11th July 2016
            
            if success {
                
                print("Object has been saved.")
                
            } else {
                
                if error != nil {
                    
                    print (error!)
                    
                } else {
                    
                    print ("Error")
                }
                
            }
}
 */

        
/*
                /* sending data to parse */
                let newObject = PFObject(className: "Users");
                
                newObject["Users"] = "Danny";
                
                newObject.saveInBackground { (happyDay, noWork) -> Void in
                    
                    if happyDay  {
                        
                        print(newObject["Users"]);
                        
                    } else {
                        
                        if noWork != nil {
                            
                            print(noWork!);
                            
                        } else {
                            
                            print("There was a problem saving the new user? ");
                            
                    }
                }
            }
*/
        
        // retrieving data from parse
/*
        let query = PFQuery(className: "Users");
        
        query.getObjectInBackground(withId: "RaHZ3AaLco") { (ObjectRetrieve, Problemo) in
            
            if Problemo != nil {
                
                print(Problemo!);
                
            } else {
                
                if let UserInClass = ObjectRetrieve {
                    
                    print(UserInClass);
                    
                    print(UserInClass["Users"]);
                    
                }
            }
        }
*/
        // save and update the class
        /*
        let query = PFQuery(className: "Users");
        
        query.getObjectInBackground(withId: "RaHZ3AaLco") { (ObjectSave, ProblemHad) in
            if ProblemHad != nil {
                
                print(ProblemHad!);
                
            } else {
                
                if let UserClassIn = ObjectSave {
                    
                    UserClassIn["Users"] = "Brandon";
                    
                    UserClassIn.saveInBackground( block: { (saved, notSaved) in
                        
                        if saved {
                        
                            print("New name has been saved?");
                            
                        } else {
                            
                            print(notSaved!);
                            
                        }
                    })
                }
            }
        }
        
    }

     */
        
        
      if PFUser.current() != nil {
        
        performSegue(withIdentifier: "LogInIdentifier", sender: self);
        
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
